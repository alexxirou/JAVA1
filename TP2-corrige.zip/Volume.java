/** Volume géométrique tri-dimentionnel */
public interface Volume {
	/** @return le volume total en m³ */
	public double getVolume();
}
