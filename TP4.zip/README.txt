
                    ╔══════════╗
                    ║ TP Pizza ║
                    ╚══════════╝

Introduction :
──────────────
On vous fournit le travail préparatoire à une application graphique
de préparation en temps réel de pizzas suivant différentes recettes.
Cependant ce travail est inachevé…

Même si vous ne maîtrisez pas les technologies employées : Swing+CDI,
vous devrez utiliser vos connaissances en programmation objets pour
comprendre la structure générale du programme
et déterminer où et comment apporter des modifications efficaces.
Le tout sans vous laisser dérouter ou perdre dans l'inconnu.

Vous prendrez soin de :
  — documenter vos modifications (en usant de commentaires adéquats),
  — respecter dans la mesure du possible les principes de conception
    (sans trop altérer le code d'origine fourni),
  — ne pas vous répéter (DRY = Don't Repeat Yourself),
    c.-à-d. ne pas écrire deux fois du code qui fait la même chose

Notes :
  — dé‑zippez dans le répertoire du projet
  — compilation en ligne de commande :
      javac -cp weld-se.jar:. @<(find . -name '*.java')
  – execution en ligne de commande :
      java -cp weld-se.jar:. Main
  — dans un IDE (Eclipse ou autre) :
     ⋅ ajoutez weld-se.jar au chemin de compilation (Build Path) via clic droit


Exercice 1: Carte de pizzas
───────────
	Faites fonctionner la première partie du programme :
	
	1.1)
	  ⋅ Assurez vous que les boutons ont des libellés corrects :
	  nom de la pizza en gras et la liste des ingrédients sur une autre ligne
	  
	Indications :
	  — pour cela il faut passer au constructeur de JButton
	    une chaîne de caractères sous la forme :
	      <html><center><b>ma pizza</b></center>liste des ingredients</html>
	  — la classe java.util.Arrays dispose d'une méthode de classe
	    nommée toString produisant une représentation à partir d'un tableau

	1.2)
	  ⋅ Assurez vous qu'il y ait deux types de pâtes différentes :
	      Classique ou Américaine
	  Liste des pizza Américaines (les autres sont des Classiques) :
	    Regina, Marinara, Capricciosa, Pepperoni et Hawaïenne 
	  ⋅ Ajustez les libellés pour le mentionner sur la carte
	  (sur une ligne avant les ingrédients) :
	    → Classique : pâte fine et croustillante
	    → Américaine: pâte épaisse et moelleuse 

Exercice 2: Préparation des pizzas
───────────
    2.1)
      ⋅ implémentez Etape[] Pizza.getPreparation() : cette méthode doit
      donner la liste des étapes nécessaires à la préparation de la dite
      pizza (donnez des descriptions explicites) :
         — Étaler la pâte : 1mn30 pour la classique, 1mn pour l'américaine
         — Disposer chaque ingrédient un par un : 30s par ingrédient 
         — passer au four :
           → Classique :  1mn à 400°C
           → Américaine : 5mn à 310°C

    Indications :
      — Etape[] e = new Etape[8]; créé un tableau de 8 cases vides
        (e.length vaut 8).

Exercice 3: Réaliste !
───────────
    3.1)
     ⋅ Assurez vous qu'il n'y ait pas plus de 5 pizzas en cours de préparation
     en même temps (ignorez les commandes en trop)
