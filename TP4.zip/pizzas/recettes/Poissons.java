package pizzas.recettes;

import javax.enterprise.inject.Produces;
import javax.inject.Named;

import pizzas.Ingredient;

public class Poissons {

	@Produces @Named public Ingredient anchois = new Ingredient("Anchois");

}
