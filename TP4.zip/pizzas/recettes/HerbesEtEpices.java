package pizzas.recettes;

import javax.enterprise.inject.Produces;
import javax.inject.Named;

import pizzas.Ingredient;

public class HerbesEtEpices {

	@Produces @Named public Ingredient basilic = new Ingredient("Basilic");
	@Produces @Named public Ingredient origan = new Ingredient("Origan");
	@Produces @Named public Ingredient capres = new Ingredient("Capres");
	@Produces @Named public Ingredient ail = new Ingredient("Ail");
	@Produces @Named("huile d'olive") public Ingredient huile = new Ingredient("Huile d'olive");

}
