package pizzas.recettes;

import javax.enterprise.inject.Produces;
import javax.inject.Named;

import pizzas.Ingredient;

public class Fromages {

	@Produces @Named public Ingredient mozzarella = new Ingredient("Mozzarella");
	@Produces @Named public Ingredient emmental = new Ingredient("Emmental");

}
