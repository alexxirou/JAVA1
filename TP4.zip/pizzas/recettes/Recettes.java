package pizzas.recettes;

import javax.enterprise.inject.Produces;
import javax.inject.Named;

import pizzas.Ingredient;
import pizzas.Pizza;

public class Recettes {
	
	@Produces @Named Pizza margherita(
			@Named("tomate") Ingredient t,
			@Named("mozzarella") Ingredient m,
			@Named("basilic") Ingredient b,
			@Named("huile d'olive") Ingredient h
	) {
		return new Pizza("Margherita Ole!", t, m, b, h);
	}

	@Produces @Named Pizza regina(
			@Named("tomate") Ingredient t,
			@Named("mozzarella") Ingredient m,
			@Named("jambon") Ingredient j,
 			@Named("champignon") Ingredient c
			) {
		return new Pizza("Regina", t, m, j, c);
	}

	@Produces @Named Pizza napolitaine(
			@Named("tomate") Ingredient t,
			@Named("mozzarella") Ingredient m,
			@Named("anchois") Ingredient a,
			@Named("olivesNoires") Ingredient on,
			@Named("origan") Ingredient or,
			@Named("huile d'olive") Ingredient h
			) {
		return new Pizza("Napoletana", t, m, a, on, or, h);
	}
	
	@Produces @Named Pizza marinara(
			@Named("tomate") Ingredient t,
			@Named("ail") Ingredient a,
			@Named("origan") Ingredient or,
			@Named("huile d'olive") Ingredient h
			) {
		return new Pizza("Marinara", t, a, or, h);
	}
	
	@Produces @Named Pizza diavola(
			@Named("mozzarella") Ingredient m,
			@Named("tomate") Ingredient t,
			@Named("chorizo") Ingredient c
			) {
		return new Pizza("Diavola", m, t, c);
	}
	
	@Produces @Named Pizza romaine(
			@Named("tomate") Ingredient t,
			@Named("mozzarella") Ingredient m,
			@Named("anchois") Ingredient a,
			@Named("origan") Ingredient o,
			@Named("champignon") Ingredient ch
			) {
		return new Pizza("Romaine", t, m, a, o, ch);
	}

	@Produces @Named Pizza sicilienne(
			@Named("tomate") Ingredient t,
			@Named("mozzarella") Ingredient m,
			@Named("basilic") Ingredient b,
			@Named("anchois") Ingredient a,
			@Named("capres") Ingredient c,
			@Named("champignon") Ingredient ch
			) {
		return new Pizza("Sicilienne", t, m, b, a, c, ch);
	}

	@Produces @Named Pizza capricciosa(
			@Named("mozzarella") Ingredient m,
			@Named("champignon") Ingredient ch,
			@Named("artichaut") Ingredient a,
			@Named("jambon") Ingredient j,
			@Named("olives") Ingredient o,
			@Named("huile d'olive") Ingredient h
			) {
		return new Pizza("Capricciosa", m, ch, a, j, o, h);
	}

	@Produces @Named Pizza pepperoni(
			@Named("mozzarella") Ingredient m,
			@Named("tomate") Ingredient t,
			@Named("chorizo") Ingredient c,
			@Named("poivrons") Ingredient p,
			@Named("champignon") Ingredient ch
			) {
		return new Pizza("Pepperoni", m, t, c, p, ch);
	}

	@Produces @Named Pizza hawaienne (
			@Named("tomate") Ingredient t,
			@Named("mozzarella") Ingredient m,
			@Named("jambon") Ingredient j,
			@Named("ananas") Ingredient a
			) {
		return new Pizza("Hawaïenne", t, m, j, a);
	}

}
