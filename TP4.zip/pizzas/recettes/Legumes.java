package pizzas.recettes;

import javax.enterprise.inject.Produces;
import javax.inject.Named;

import pizzas.Ingredient;

public class Legumes {

	@Produces @Named public Ingredient tomate = new Ingredient("Tomate");
	@Produces @Named public Ingredient poivrons = new Ingredient("Poivrons");
	@Produces @Named public Ingredient artichaut = new Ingredient("Artichaut");
	@Produces @Named public Ingredient champignon = new Ingredient("Champignons");
	@Produces @Named public Ingredient olives = new Ingredient("Olives");
	@Produces @Named public Ingredient olivesNoires = new Ingredient("Olives noires");

	@Produces @Named public Ingredient ananas = new Ingredient("Ananas");
}
