package pizzas.recettes;

import javax.enterprise.inject.Produces;
import javax.inject.Named;

import pizzas.Ingredient;

public class Viandes {

	@Produces @Named public Ingredient jambon = new Ingredient("Jambon");
	@Produces @Named public Ingredient chorizo = new Ingredient("Chorizo");

}
