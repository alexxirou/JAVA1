package pizzas.menus;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.enterprise.inject.Produces;
import javax.inject.Named;

import pizzas.Pizza;


public class CarteDuJour {
	@Produces
	public static Pizza[] carte(
			@Named("margherita") Pizza margherita,
			@Named("regina") Pizza regina,
			@Named("napolitaine") Pizza napolitaine,
			@Named("marinara") Pizza marinara,
			@Named("diavola") Pizza diavola,
			@Named("romaine") Pizza romaine,
			@Named("sicilienne") Pizza sicilienne,
			@Named("capricciosa") Pizza capricciosa,
			@Named("pepperoni") Pizza pepperoni,
			@Named("hawaienne") Pizza hawaienne
			) {
		int jour = new GregorianCalendar().get(Calendar.DAY_OF_WEEK);
		if (jour % 2 == 1)
			return new Pizza[] {
				margherita, regina, napolitaine,
				marinara, diavola, romaine,
				capricciosa, hawaienne
			};
		else
			return new Pizza[] {
				margherita, regina, napolitaine,
				marinara, diavola, sicilienne,
				capricciosa, pepperoni
			};
	}
}
