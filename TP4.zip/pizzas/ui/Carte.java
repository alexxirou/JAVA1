package pizzas.ui;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import pizzas.Pizza;

@Singleton
public class Carte implements Runnable, ActionListener {

	@Inject
	private Pizza[] pizzas;

	public void run() {	
		JFrame frame = new JFrame("Pizzas");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel panel = new JPanel(new GridLayout(1+pizzas.length / 3 ,3));
		for (int i = 0; i < pizzas.length; i++) {
			JButton button = new JButton("" + pizzas[i]);
			button.setFont(button.getFont().deriveFont(Font.PLAIN));
			button.setActionCommand(Integer.toString(i));
			button.addActionListener(this);
			panel.add(button);
		}
		frame.add(panel);
		frame.pack();
		frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		int i = Integer.parseInt(e.getActionCommand());
		Cuisine.preparation(pizzas[i]);
	}

}
