package pizzas.ui;

import java.awt.BorderLayout;
import java.awt.Insets;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import pizzas.Pizza;

class Cuisine extends WindowAdapter implements Runnable, PropertyChangeListener {

	private JProgressBar progress;
	private JTextArea output;
	private JFrame frame;
	private Preparation preparation;

	private JComponent createUI() {
		JPanel cuisine = new JPanel(new BorderLayout());
		progress = new JProgressBar();
		progress.setValue(0);
		output = new JTextArea(5, 20);
		output.setMargin(new Insets(5, 5, 5, 5));
		output.setEditable(false);
		cuisine.add(progress, BorderLayout.PAGE_START);
		cuisine.add(new JScrollPane(output), BorderLayout.CENTER);
		cuisine.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
		return cuisine;
	}

	@Override
	public void run() {
		frame = new JFrame("preparation");
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(this);
        frame.setContentPane(createUI());
		frame.pack();
		frame.setVisible(true);
	}

	public static void preparation(Pizza pizza) {
		Cuisine cuisto = new Cuisine();
		SwingUtilities.invokeLater(cuisto);
		cuisto.preparation = new Preparation(cuisto, pizza);
		cuisto.preparation.addPropertyChangeListener(cuisto);
		cuisto.preparation.execute();
	}

	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		if ("progress".equals(evt.getPropertyName()))
			progress.setValue((int)evt.getNewValue());
	}
	
	public void append(String etape)
	{ output.append(etape); output.append("\n"); }

	@Override
	public void windowClosing(WindowEvent e) {
		if (preparation != null)
			preparation.cancel(true);
	}

	public void done() {
		if (frame != null) {
			frame.setVisible(false);
			frame.dispose();
		}
	}

}
