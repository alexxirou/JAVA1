package pizzas.ui;

import java.util.List;

import javax.swing.SwingWorker;

import pizzas.Etape;
import pizzas.Pizza;

class Preparation extends SwingWorker<Void, String> {

	Pizza pizza;
	Cuisine cuisine;

	Preparation(Cuisine cuisine, Pizza pizza) {
		this.cuisine = cuisine;
		this.pizza = pizza;
	}

	@Override
	protected Void doInBackground() throws Exception {
		int progression = 0, total = 0;
		int i = 0;
		Etape[] etapes = pizza.getPreparation();
		// temps total pour toutes les taches 
		for (Etape etape : etapes)
			total += etape.duree();
		while (!isCancelled() && i < etapes.length) {
			publish(etapes[i].description()); // annonce de la préparation
			int duree = etapes[i].duree();
			while (!isCancelled() && duree > 0) {
				Thread.sleep(1000); // faire prends du temps, ici 1s par 1s
				progression++; duree--; // transférer 1s de durée à progression
				setProgress((100*progression)/total); // m-à-j du %
			}
		}
		return null;
	}

	@Override
	protected void process(List<String> etapes) {
		for (String etape : etapes)
			cuisine.append(etape);
	}

	@Override
	protected void done() { cuisine.done(); }

}
