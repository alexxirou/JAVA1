package pizzas;

public class Ingredient {

	public Ingredient(String nom) { }

}
