package pizzas;

public class Pizza {
	
	public Pizza(String nom, Ingredient... ingredients) { }

	public Etape[] getPreparation() { return new Etape[0]; }
	
}
