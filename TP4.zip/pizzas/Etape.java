package pizzas;

public interface Etape {
	int duree();
	String description();
}
