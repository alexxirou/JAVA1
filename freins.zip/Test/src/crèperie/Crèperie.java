package crèperie;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import crèpe.Crèpe;
import crèpe.Salée;
import crèpe.Sucrée;
import ingredient.Emmental;
import ingredient.Jambon;
import ingredient.Nutella;
import ingredient.Sucre;
import ingredient.Œuf;

public abstract class Crèperie {
	
	private final Map<String, Recette> recettes;

	public Crèperie() {
		this.recettes = getRecettes();
	}
	
	protected Map<String,Recette> getRecettes() {
		HashMap<String, Recette> recettes = new HashMap<String, Recette>();
		recettes.put("Oeuf", this::nouvelleOeuf);
		recettes.put("Sucre", this::nouvelleOeuf);
		recettes.put("Nutella", this::nouvelleOeuf);
		return recettes;
	}

	public Crèpe vendre(String nom) throws CrèpeNotFoundException {
		if (! recettes.containsKey(nom))
			throw new CrèpeNotFoundException(nom);
		Crèpe c = recettes.get(nom).nouvelle();
		c.préparer();
		return c;
	}

	public Crèpe vendreRéflection(String nom) throws CrèpeNotFoundException {
		try {
			Method method = getClass().getMethod("nouvelle" + nom);
			Crèpe c = (Crèpe) method.invoke(this);
			c.préparer();
			return c;
		} catch (NoSuchMethodException | SecurityException
				| IllegalAccessException | IllegalArgumentException
				| InvocationTargetException ex) {
			throw new CrèpeNotFoundException(nom, ex);
		}
	}

	public Crèpe nouvelleOeuf() {
		return new Salée(new Œuf(), new Jambon(), new Emmental());
	}
	public Crèpe nouvelleSucre() {
		return new Sucrée(new Sucre());
	}
	public Crèpe nouvelleNutella() {
		return new Sucrée(new Nutella());
	}

}
