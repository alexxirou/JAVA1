package crèperie;
import java.util.Map;

import crèpe.Crèpe;
import crèpe.Salée;
import crèpe.Sucrée;
import ingredient.ConfitureQuetsches;
import ingredient.Munster;

public class CrèperieStrasbourg extends Crèperie {

	@Override
	protected Map<String, Recette> getRecettes() {
		Map<String, Recette> recettes = super.getRecettes();
		recettes.put("Munster", this::nouvelleMunster);
		recettes.put("Quetsche", this::nouvelleQuetsche);
		return recettes;
	}
	public Crèpe nouvelleMunster() {
		return new Salée(new Munster());
	}
	public Crèpe nouvelleQuetsche() {
		return new Sucrée(new ConfitureQuetsches());
	}

}
