package crèperie;
import java.util.Map;

import crèpe.Crèpe;
import crèpe.Sucrée;
import ingredient.CaramelBeurreSalé;

public class CrèperieBrest extends Crèperie {

	@Override
	protected Map<String, Recette> getRecettes() {
		Map<String, Recette> recettes = super.getRecettes();
		recettes.put("Caramel", this::nouvelleCaramel);
		return recettes;
	}
	public Crèpe nouvelleCaramel() {
		return new Sucrée(new CaramelBeurreSalé());
	}
}
