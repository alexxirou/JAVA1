package crèperie;

@SuppressWarnings("serial")
public class CrèpeNotFoundException extends Exception {
	public CrèpeNotFoundException(String nom) {
		super("Crèpe " + nom + " n'existe pas");
	}

	public CrèpeNotFoundException(String nom, Exception ex) {
		super("Crèpe " + nom + " n'existe pas", ex);		
	}
}
