package crèperie;
import crèpe.Crèpe;

public interface Recette {
	Crèpe nouvelle();
}