package crèpe;
import java.util.Arrays;

import ingredient.Ingredient;

public abstract class Crèpe {

	protected Ingredient[] ingrédients;

	public Crèpe(Ingredient... ingrédients) {
		this.ingrédients = ingrédients;
	}

	@Override
	public String toString() {
		return getPâte() + " ingrédients=" + Arrays.toString(ingrédients);
	}

	public void préparer() {
		étaler();
		attendre();
		retourner();
		disposerEtAttendre();
		plier();
		servir();
	}

	protected void étaler() {
		System.out.println("étaler "+getPâte());
	}

	protected abstract String getPâte();

	private void servir() {
		System.out.println("servir");
	}

	protected abstract void plier();

	protected void disposer() {
		for (Ingredient ingredient : ingrédients) {
			System.out.println("disposer " + ingredient);
		}
	}

	protected abstract void disposerEtAttendre();

	private void retourner() {
		System.out.println("retourner");
	}

	protected void attendre() {
		System.out.println("attendre");
	}

}
