package crèpe;
import ingredient.Ingredient;

public class Salée extends Crèpe {

	public Salée(Ingredient... ingredients) {
		super(ingredients);
	}

	@Override
	protected String getPâte() {
		return "pâte au Sarrazin";
	}
	@Override
	protected void plier() {
		System.out.println("plier en portefeuille");
	}

	@Override
	protected void disposerEtAttendre() {
		disposer();
		attendre();
	}

}
