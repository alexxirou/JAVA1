package crèpe;
import ingredient.Ingredient;

public class Sucrée extends Crèpe {

	public Sucrée(Ingredient... ingredients) {
		super(ingredients);
	}

	@Override
	protected String getPâte() {
		return "pâte Sucrée";
	}
	@Override
	protected void plier() {
		System.out.println("plier en triangle");
	}

	@Override
	protected void disposerEtAttendre() {
		attendre();
		disposer();
	}

}
