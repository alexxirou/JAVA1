import java.util.Scanner;

import crèpe.Crèpe;
import crèperie.CrèpeNotFoundException;
import crèperie.Crèperie;
import crèperie.CrèperieBrest;
import crèperie.CrèperieStrasbourg;

public class Programme {
	
	public static void main(String[] args) throws CrèpeNotFoundException {
		try(Scanner in = new Scanner(System.in);) {
			System.out.println("Crèperie [0:Strasbourg, 1:Brest] ?");
			Crèperie crèperie =
					in.nextInt() <= 0 ? new CrèperieStrasbourg() : new CrèperieBrest();
			System.out.println("Recette ?");
			Crèpe c = crèperie.vendre(in.next());
			System.out.println("crèpe " + c);
		}
	}
}
