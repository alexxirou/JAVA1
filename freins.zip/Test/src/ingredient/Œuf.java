package ingredient;

public class Œuf implements Ingredient {
	@Override public String toString() {
		return "Œuf";
	}
}
