package ingredient;
public class CaramelBeurreSalé implements Ingredient {
	@Override public String toString() {
		return "Caramel au beurre salé";
	}
}
