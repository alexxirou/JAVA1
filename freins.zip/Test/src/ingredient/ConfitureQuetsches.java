package ingredient;
public class ConfitureQuetsches implements Ingredient {
	@Override public String toString() {
		return "Confiture de Quetsches";
	}
}
