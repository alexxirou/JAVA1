package ingredient;

public class Sucre implements Ingredient {
	@Override public String toString() {
		return "Sucre";
	}
}
