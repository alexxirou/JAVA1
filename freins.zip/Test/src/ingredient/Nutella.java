package ingredient;

public class Nutella implements Ingredient {
	@Override public String toString() {
		return "Nutella";
	}
}
