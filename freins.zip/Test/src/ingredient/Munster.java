package ingredient;

public class Munster implements Ingredient {
	@Override public String toString() {
		return "Munster";
	}
}
