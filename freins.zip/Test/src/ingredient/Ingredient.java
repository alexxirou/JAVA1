package ingredient;

public interface Ingredient {}
