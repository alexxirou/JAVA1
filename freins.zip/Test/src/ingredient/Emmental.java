package ingredient;

public class Emmental implements Ingredient {
	@Override public String toString() {
		return "Emmental";
	}
}
