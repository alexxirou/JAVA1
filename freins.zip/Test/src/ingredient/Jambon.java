package ingredient;

public class Jambon implements Ingredient {
	@Override public String toString() {
		return "Jambon";
	}
}
